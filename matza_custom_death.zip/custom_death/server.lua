RegisterServerEvent("custom_death:playerDied")
AddEventHandler("custom_death:playerDied", function()
    local src = source
    TriggerClientEvent("custom_death:showMessage", src)
end)

RegisterServerEvent("custom_death:revivePlayer")
AddEventHandler("custom_death:revivePlayer", function()
    local src = source
    TriggerClientEvent("custom_death:hideMessage", src)
end)
