local isDead = false

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000) -- Performans için 1 saniyede bir kontrol edelim.

        local ped = PlayerPedId()
        if IsEntityDead(ped) and not isDead then
            isDead = true
            TriggerEvent("custom_death:showMessage")
        elseif not IsEntityDead(ped) and isDead then
            isDead = false
            TriggerEvent("custom_death:hideMessage")
        end
    end
end)

RegisterNetEvent("custom_death:showMessage")
AddEventHandler("custom_death:showMessage", function()
    local displayTime = 30000 -- 15 saniye (15000 ms)
    local startTime = GetGameTimer()

    while (GetGameTimer() - startTime) < displayTime do
        Citizen.Wait(0) -- Her karede ekrana yazıyı çiz.

        SetTextFont(4)
        SetTextScale(0.8, 0.8)
        SetTextColour(255, 0, 0, 255)
        SetTextDropshadow(1, 0, 0, 0, 255)
        SetTextEdge(1, 0, 0, 0, 255)
        SetTextDropShadow()
        SetTextOutline()
        SetTextCentre(true)
        SetTextEntry("STRING")
        AddTextComponentString("Ambulans çagırıldı! Biraz bekle ve yardım gelmezse /help komutunu kullan. ")
        DrawText(0.5, 0.8)
    end
end)
