fx_version 'cerulean'
game 'gta5'

author 'matza'
description 'Ölüm Ekranı Mesajı'
version '1.0.0'

client_script 'client.lua'
server_script 'server.lua'
